import React from "react";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
// import FormControlLabel from "@material-ui/core/FormControlLabel";

export default class StudentEntry extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: "",
      score: ""
    };
  }

  onChange = e => {
    let value = e.target.value;
    let name = e.target.name;
    this.setState({ [name]: value });
  };

  onClear() {
    this.setState({ id: "", score: "" });
    this.props.clearCallback();
  }

  onAdd() {
    const { id, score } = this.state;
    const info = { id, score };
    this.props.addCallback(info);
  }

  render() {
    return (
      <div className="Table">
        <div className="Row">
          <div className="Cell">Name:</div>
          <div className="Cell">
            <TextField
              name="id"
              label="Student name"
              value={this.state.id}
              onChange={this.onChange.bind(this)}
            />
          </div>
        </div>
        <div className="Row">
          <div className="Cell">Score:</div>
          <div className="Cell">
            <TextField
              name="score"
              label="Student score"
              value={this.state.score}
              onChange={this.onChange.bind(this)}
            />
          </div>
        </div>
        <div className="Row">
          <div className="Cell">&nbsp;</div>
        </div>
        <div className="Row">
          <div className="Cell">&nbsp;</div>
          <div className="Cell">
            <Button
              variant="contained"
              color="primary"
              onClick={this.onAdd.bind(this)}
            >
              Add Scores
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="secondary"
              onClick={this.onClear.bind(this)}
            >
              Clear Scores
            </Button>
          </div>
        </div>
      </div>
    );
  }
}
