import React from "react";

export default class NewClassComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <h1>Empty class component</h1>
      </div>
    );
  }
}
