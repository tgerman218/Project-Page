import React from "react";
import ErrorBoundary from "./ErrorBoundary.js";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import StudentList from "./StudentList.js";
import StudentEntry from "./StudentEntry.js";
import Chart from "./BarChart.js";
import Scores from "./Scores.js";

const studentIdField = "id";

export default class Student extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      count: 0,
      max: 0,
      min: 0,
      average: 0,
      grades: [
        { Grade: "A", Students: 0 },
        { Grade: "B", Students: 0 },
        { Grade: "C", Students: 0 },
        { Grade: "D", Students: 0 },
        { Grade: "F", Students: 0 }
      ]
    };
  }

  compare = (a, b) => {
    if (a.id < b.id) return -1;
    if (a.id > b.id) return 1;
    return 0;
  };

  addCallback = info => {
    const data = this.state.data;
    data.push(info);
    data.sort(this.compare);
    this.scoreData(data);
    this.setState({ data });
    // console.log(this.state.data);
  };

  deleteCallback = id => {
    const data = this.state.data
      .slice()
      .filter(val => val[studentIdField] !== id);
    this.setState({ data });
    this.scoreData(data);
  };

  clearCallback = () => {
    const data = [];
    let { count, max, min, average } = 0;
    let grades = [
      { Grade: "A", Students: 0 },
      { Grade: "B", Students: 0 },
      { Grade: "C", Students: 0 },
      { Grade: "D", Students: 0 },
      { Grade: "F", Students: 0 }
    ];
    this.setState({ data, count, max, min, average, grades });
  };

  scoreData = data => {
    let grades = [
      { Grade: "A", Students: 0 },
      { Grade: "B", Students: 0 },
      { Grade: "C", Students: 0 },
      { Grade: "D", Students: 0 },
      { Grade: "F", Students: 0 }
    ];
    let sum = 0;
    let count = data.length;
    let max = -1;
    let min = 100;
    let average = 0;
    let score = 0;

    for (let i = 0; i < count; i++) {
      if (data[i].score > max) {
        max = parseInt(data[i].score);
      }
    }

    for (let i = 0; i < count; i++) {
      if (data[i].score < min) {
        min = parseInt(data[i].score);
      }
    }

    for (let i = 0; i < count; i++) {
      sum += parseInt(data[i].score);
    }
    if (sum > 0) {
      average = sum / count;
    } else {
      average = 0;
    }

    for (let i = 0; i < count; i++) {
      score = parseInt(data[i].score);
      if (score >= 90) {
        grades[0].Students += 1;
      } else if (score >= 80 && score < 90) {
        grades[1].Students += 1;
      } else if (score >= 70 && score < 80) {
        grades[2].Students += 1;
      } else if (score >= 60 && score < 70) {
        grades[3].Students += 1;
      } else {
        grades[4].Students += 1;
      }
    }
    this.setState({ count, max, min, average, grades });
  };

  render() {
    return (
      <ErrorBoundary>
        <div className="App">
          <h1>Student Scores</h1>
          <Grid className="grid-container" justify="center">
            <StudentList
              data={this.state.data}
              idField={studentIdField}
              deleteCallback={this.deleteCallback}
            />
            <Paper className="StudentEntry">
              <StudentEntry
                addCallback={this.addCallback}
                clearCallback={this.clearCallback}
              />
            </Paper>
            <Scores
              average={this.state.average}
              min={this.state.min}
              max={this.state.max}
              count={this.state.count}
            />
            <Chart grades={this.state.grades} />
          </Grid>
        </div>
      </ErrorBoundary>
    );
  }
}
