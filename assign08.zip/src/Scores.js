import React from "react";

export default class Scores extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="StudentEntry">
        <div>Count: {this.props.count}</div>
        <div>Max: {this.props.max}</div>
        <div>Min: {this.props.min}</div>
        <div>Average: {this.props.average}</div>
      </div>
    );
  }
}
