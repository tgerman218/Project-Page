import React from "react";
// import MaterialTable from "material-table";
// import {
//   Search,
//   ViewColumn,
//   SaveAlt,
//   ChevronLeft,
//   ChevronRight,
//   FirstPage,
//   LastPage,
//   Check,
//   FilterList,
//   Remove
// } from "@material-ui/icons";
import { Delete } from "@material-ui/icons";
// import { List, ListItem } from "@material-ui/core/List";
// import Button from "@material-ui/core/Button";

const ActionIconComponent = props => <div>{props.icon}</div>;

export default class StudentList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  onDeleteClick = (item, index) => {
    let data = this.props.data.slice();
    data.splice(index, 1);
    this.setState({ data });
    this.props.deleteCallback(item.id);
  };

  // onDeleteClick = (e, rowData) => {
  //   this.props.deleteCallback(rowData[this.props.idField]);
  // }

  render() {
    let data = this.props.data.slice();
    let list = data.map((elem, index) => (
      <div className="Row" key={index}>
        <div className="Cell">
          <span className="ListItem" id={index}>
            {elem.id} &nbsp;
            {elem.score} &nbsp;
            <button
              className="ListItem Clickable"
              onClick={() => this.onDeleteClick(elem, index)}
            >
              x
            </button>
          </span>
        </div>
      </div>
    ));
    // let data = this.props.data;
    // let list = data.sort().map((item, index) => (
    //   <div id={index} className="Table Cell">
    //     <div className="ListItem" key={index}>
    //       {item.id} &nbsp;
    //       {item.score} &nbsp;
    //       <button
    //         className="ListItem Clickable"
    //         id={index}
    //         onClick={this.onDeleteClick}
    //       >
    //         x
    //       </button>
    //     </div>
    //   </div>
    // ));
    return (
      <div className="dialog-window">
        <div className="scrollable-content" style={{ maxWidth: "100%" }}>
          {list}
        </div>
      </div>
    );
  }
}

//   render() {
//     return (
//       <div style={{ maxWidth: "100%" }}>
//         <MaterialTable
//           columns={this.props.columns}
//           data={this.props.data}
//           title="Student Scores"
//           options={{
//             actionsColumnIndex: -1
//           }}
//           icons={{
//             Check: Check,
//             DetailPanel: ChevronRight,
//             Export: SaveAlt,
//             Filter: FilterList,
//             FirstPage: FirstPage,
//             LastPage: LastPage,
//             NextPage: ChevronRight,
//             PreviousPage: ChevronLeft,
//             Search: Search,
//             ThirdStateCheck: Remove,
//             ViewColumn: ViewColumn
//           }}
//           actions={[
//             {
//               icon: ActionIconComponent,
//               iconProps: { icon: <Delete /> },
//               name: "delete",
//               onClick: this.onDeleteClick
//             }
//           ]}
//         />
//       </div>
//     );
//   }
// }
