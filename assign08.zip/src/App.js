import React from "react";
import ErrorBoundary from "./ErrorBoundary.js";
import Grid from "@material-ui/core/Grid";
import Student from "./Student.js";
import Scores from "./Scores.js";
import Paper from "@material-ui/core/Paper";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  onAddStudent = info => {
    const data = this.state.data.slice();
    //const { data } = this.state;
    data.push(info);
    this.setState({ data });
  };

  render() {
    return (
      <ErrorBoundary>
        <div className="App">
          <Grid container justify="center">
            <Student />
          </Grid>
        </div>
      </ErrorBoundary>
    );
  }
}
